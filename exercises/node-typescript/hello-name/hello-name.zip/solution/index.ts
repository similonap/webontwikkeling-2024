import readline from 'readline-sync';

const name : string = readline.question("What's your name? ");

console.log(`Hello, ${name}!`);

export {}