import readline from 'readline-sync';

interface Todo {
    id: number;
    title: string;
    completed: boolean;
}

async function getData() {
    let todos: Todo[];

    try { 
        let response = await fetch("https://jsonplaceholder.typicode.com/todos/");
        todos = await response.json();
        todos = todos.splice(0, 20);
        return todos;
    } catch(error: unknown) {
        if (error instanceof Error){
            console.log(error.message)
        }
        // We returnen een lege array, omdat we anders "undefined" returnen bij een fout.
        return [];
    }
}


async function init() {   
    // Async functies wrappen hun returned data automatisch in een nieuwe promise, dus hier moeten we ook nog een await doen.
    let todos = await getData();
    let nextId: number = 1;
    
    const menuItems: string[] = [
        "Add a task",
        "Show tasks",
        "Check a task",
        "Exit"
    ];
    
    let running: boolean = true;
    do {
        let option: number = readline.keyInSelect(menuItems, "What do you want to do?", { cancel: false });
        if (option === 0) {
            let title: string = readline.question("Enter a task: ");
            todos.push({ id: nextId++, title: title, completed: false });
        } else if (option === 1) {
            for (let todo of todos) {
                console.log(`${todo.id}. [${todo.completed ? 'X' : ' '}] ${todo.title}`);
            }
        } else if (option === 2) {
            let todoTitles : string[] = [];
            for (let todo of todos) {
                if (!todo.completed) {
                    todoTitles.push(todo.title);        
                }
            }
            let taskIndex: number = readline.keyInSelect(todoTitles, "Which task did you complete?", { cancel: false });
            let todoTitle: string = todoTitles[taskIndex];
            for (let todo of todos) {
                if (todo.title === todoTitle) {
                    todo.completed = true;
                }
            }
        } else if (option === 3) {
            running = false;
        }
    } while (running);
}
init();