import { login } from "./database";

test("Example test", () => {
    expect(true).toBe(true);
});