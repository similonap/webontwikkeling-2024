export interface NewsArticle {
    id: number;
    title: string;
    content: string;
    topic: string;
}
