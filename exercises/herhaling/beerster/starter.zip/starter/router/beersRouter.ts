import express from "express";

export function beersRouter() {
    const router = express.Router();

    return router;
}