import express from "express";

export default function profileRouter() {
    const router = express.Router();

    router.get("/", async (req, res) => {
        
    });

    return router;
}