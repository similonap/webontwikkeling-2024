import express from "express";

export default function loginRouter() {
    const router = express.Router();

    return router;
}