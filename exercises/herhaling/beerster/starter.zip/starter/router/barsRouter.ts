import express from "express";

export function barsRouter() {
    const router = express.Router();

    return router;
}