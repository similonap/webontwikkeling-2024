// https://sampleapis.assimilate.be/harrypotter/spells
import { ObjectId } from "mongodb";

export type SpellType = "Charm" | "Curse" | "Jinx" | "Hex" | "Transfiguration" | "Healing" | "Conjuration";

export interface Spell {
    _id?: ObjectId;
    id: number;
    name: string;
    type: SpellType;
    mana: number;
    description: string;
}