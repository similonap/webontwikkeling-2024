import { add, subtract, multiply, divide } from './math'; 

// Write your tests here

